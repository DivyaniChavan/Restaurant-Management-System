package com.restaurant.service;

import java.util.Optional;

import com.restaurant.entity.User;

public interface UserService 
{
	void saveUser(User user);
	Optional<User> findByUsername(String username);
}