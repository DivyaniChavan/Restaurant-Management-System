package com.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantMangementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantMangementSystemApplication.class, args);
	}

}
