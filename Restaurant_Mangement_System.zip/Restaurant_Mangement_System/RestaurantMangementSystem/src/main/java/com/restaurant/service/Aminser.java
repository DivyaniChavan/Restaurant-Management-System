package com.restaurant.service;

import com.restaurant.entity.Admin;

public interface Aminser {
	Admin username(String username);
}
