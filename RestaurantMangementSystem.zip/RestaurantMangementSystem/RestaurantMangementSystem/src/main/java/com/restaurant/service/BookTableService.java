package com.restaurant.service;

import com.restaurant.entity.BookTable;


public interface BookTableService 
{
	BookTable saveBookTable(BookTable booktable);
}
